package com.arrayprolc.trails.main;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import com.arrayprolc.trails.effects.EffectManager;
import com.arrayprolc.trails.effects.EffectManager.EffectType;
import com.arrayprolc.trails.event.click.InventoryClickListener;
import com.arrayprolc.trails.event.click.JoinListener;
import com.arrayprolc.trails.event.command.CommandTest;
import com.arrayprolc.trails.event.command.CommandTrail;
import com.arrayprolc.trails.event.custom.PlayerCommandEvent;
import com.arrayprolc.trails.extra.ExtraManager;
import com.arrayprolc.trails.util.CircleParticle;
import com.arrayprolc.trails.util.ParticleManager;
import com.prismservices.dev.gtdb.mongodb.DatabaseAPI;
import com.prismservices.dev.gtdb.mongodb.dao.UserDAO;


@SuppressWarnings("deprecation")
public class TrailsCore extends JavaPlugin {

	private static TrailsCore instance;

	@Override
	public void onEnable(){
		instance = this;
		Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask(this, new Updater(this), 1L, 1L);
		
		try {
			System.out.println("[Trails] Setting up MySQL");
			setupMySQL();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		try {
			System.out.println("[Trails] Setting up listeners");
			setupListeners();
		}catch(Exception ex){
			ex.printStackTrace();
		}

	}
	
	private void setupListeners(){
		ParticleManager.registerEvents();
		ExtraManager.registerEvents(this);
		EffectManager.registerEvents(this);
		getServer().getPluginManager().registerEvents(new CommandTest(), this);
		getServer().getPluginManager().registerEvents(new CommandTrail(), this);
		getServer().getPluginManager().registerEvents(new JoinListener(), this);
		getServer().getPluginManager().registerEvents(new CircleParticle(), this);
		getServer().getPluginManager().registerEvents(new InventoryClickListener(), this);
	}

	private void setupMySQL(){
	//	System.out.println("[Trails-MySQL] MySQL has not been setup yet. Please contact the developer.");
		//TODO
		for(Player p : Bukkit.getOnlinePlayers()){
		com.prismservices.dev.gtdb.mongodb.entities.User user = DatabaseAPI.getUserByUUID(p.getUniqueId());
		if(user.activeParticle != null){
			String active = user.activeParticle;
			try{
			EffectManager.addEffect(p, getFromString(active));
			}catch(Exception ex){
				//It's null, that's ok.
			}
		}
		
		}
	}
	
	public void onDisable(){
		for(Player p : Bukkit.getOnlinePlayers()){
			com.prismservices.dev.gtdb.mongodb.entities.User user = DatabaseAPI.getUserByUUID(p.getUniqueId());
			String active = EffectManager.getEffect(p).toString();
			try{
				user.activeParticle = active;
			}catch(Exception ex){
				//It's null, that's ok.
			}
			UserDAO.getInstance().save(user);
		}
	}
	
	private EffectType getFromString(String s){
		for(EffectType e : EffectType.values()) {
			if(e.toString().equalsIgnoreCase(s)){
				return e;
			}
		}
		return null;
	}

	public static TrailsCore getInstance(){
		if(instance == null){
			instance = new TrailsCore();
		}
		return instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if(label.equalsIgnoreCase("trailstest")){
			if(!(sender instanceof Player)){
				return false;
			}
			Player p = (Player) sender;
			if(!p.isOp()){
				return false;
			}
			com.prismservices.dev.gtdb.mongodb.entities.User user = DatabaseAPI
					.getUserByUUID(p.getUniqueId());
			String active = user.activeParticle;
			if(args.length == 0){
				sender.sendMessage("�7Current Particle: " + active);
				return true;
			}
			active = args[1];
			sender.sendMessage("Changed!");
		}
		PlayerCommandEvent e = new PlayerCommandEvent(sender, command, label, args);
		getServer().getPluginManager().callEvent(e);
		return e.getDone();
	}

}
