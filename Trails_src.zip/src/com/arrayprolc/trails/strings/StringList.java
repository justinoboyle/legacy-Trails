package com.arrayprolc.trails.strings;

import org.bukkit.Bukkit;

public class StringList
{
  public static String mainWorld = Bukkit.getWorlds().get(0).getName();
}


/* Location:           A:\LC\Lobby\plugins\HubPlugin.jar
 * Qualified Name:     com.arrayprolc.trails.strings.StringList
 * JD-Core Version:    0.7.0.1
 */