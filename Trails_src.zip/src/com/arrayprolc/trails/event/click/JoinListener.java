package com.arrayprolc.trails.event.click;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import com.arrayprolc.trails.effects.EffectManager;
import com.arrayprolc.trails.effects.EffectManager.EffectType;
import com.prismservices.dev.gtdb.mongodb.DatabaseAPI;
import com.prismservices.dev.gtdb.mongodb.dao.UserDAO;

public class JoinListener implements Listener {

	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		EffectManager.removeEffect(p, false);
		com.prismservices.dev.gtdb.mongodb.entities.User user = DatabaseAPI
				.getUserByUUID(p.getUniqueId());
		try {
			if (user.activeParticle != null && !user.activeParticle.equals("nothing")) {
				String active = user.activeParticle;
				try {
					EffectManager.addEffect(p, getFromString(active));
				} catch (Exception ex) {
					// It's null, that's ok.
				}
			}
		} catch (Exception ex) {
			// It's null, that's ok.
		}
	}

	/*@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		try {
			com.prismservices.dev.gtdb.mongodb.entities.User user = DatabaseAPI
					.getUserByUUID(p.getUniqueId());
			if (!EffectManager.hasEffect(p)) {
				user.activeParticle = "nothing";
				UserDAO.getInstance().save(user);
				return;
			}
			try {
				String active = EffectManager.getEffect(p).toString();
				try {
					user.activeParticle = active;
				} catch (Exception ex) {
					// It's null, that's ok.
				}
				UserDAO.getInstance().save(user);
			} catch (Exception ex) {

			}
		} catch (Exception ex) {
			// It's null, that's ok.
		}

	}*/

	public EffectType getFromString(String s) {
		for (EffectType e : EffectType.values()) {
			if (e.toString().equalsIgnoreCase(s)) {
				return e;
			}
		}
		return null;
	}

}
