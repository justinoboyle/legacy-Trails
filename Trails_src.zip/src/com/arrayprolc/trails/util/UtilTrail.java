package com.arrayprolc.trails.util;

import org.bukkit.entity.Player;

import com.arrayprolc.trails.main.Trail;

public class UtilTrail {

	public static void startTrail(Player p, Trail trail){
		
	}
	
	public static void startTrail(Player p, String s){
		
	}
	
}
